export function getSpeedDuration(speed) {
  switch (speed) {
    case "slow":
      return 120;
    case "medium":
      return 50;
    case "fast":
      return 15;
    default:
      return 50;
  }
}

export function getColorGradient(color) {
  switch (color.toLowerCase()) {
    case "red":
      return "linear-gradient(to right, #ff9a9e, #ff0000)";
    case "purple":
      return "linear-gradient(to right, #d8b4fe, #8b5cf6)";
    case "green":
      return "linear-gradient(to right, #a8e063, #56ab2f)";
    case "blue":
      return "linear-gradient(to right, #89f7fe, #0072ff)";
    default:
      return "linear-gradient(to right, #a8e063, #56ab2f)";
  }
}
