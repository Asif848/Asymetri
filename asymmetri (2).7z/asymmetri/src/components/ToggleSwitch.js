import React from "react";

function ToggleSwitch({ reverse, setReverse, color }) {
  const switchStyle = {
    "--slider-color": color.toLowerCase()
  };

  return (
    <div className="toggle-container" style={{ color: color.toLowerCase() }}>
      <label>Reverse</label>
      <label className="switch" style={switchStyle}>
        <input
          type="checkbox"
          checked={reverse}
          onChange={() => setReverse(!reverse)}
        />
        <span className="slider-toggle"></span>
      </label>
    </div>
  );
}

export default ToggleSwitch;
