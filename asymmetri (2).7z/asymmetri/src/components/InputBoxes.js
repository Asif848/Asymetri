import React from "react";

function InputBoxes({
  color,
  totalItems,
  itemsInLine,
  handleTotalChange,
  handleItemsInLineChange,
}) {
  const dynamicColor = color.toLowerCase();

  return (
    <div className="inputs">
      <div className="input-box" style={{ borderColor: dynamicColor }}>
        <div className="input-container">
          <input
            type="number"
            value={totalItems}
            min="1"
            max="30"
            onChange={(e) => handleTotalChange(Number(e.target.value))}
            style={{ color: dynamicColor }}
            placeholder=" "
          />
          <label style={{ color: dynamicColor }}>Total Items</label>
        </div>
      </div>

      <div className="input-box" style={{ borderColor: dynamicColor }}>
        <div className="input-container">
          <input
            type="number"
            value={itemsInLine}
            min="1"
            max="15"
            onChange={(e) => handleItemsInLineChange(Number(e.target.value))}
            style={{ color: dynamicColor }}
            placeholder=" "
          />
          <label style={{ color: dynamicColor }}>Items in Line</label>
        </div>
      </div>
    </div>
  );
}

export default InputBoxes;
