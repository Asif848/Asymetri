import React, { useState } from "react";

function SliderControl({ setSpeed, color }) {
  const [position, setPosition] = useState(2);

  const handleClick = () => {
    const newPosition = position === 3 ? 1 : position + 1;
    setPosition(newPosition);

    if (newPosition === 1) setSpeed("slow");
    else if (newPosition === 2) setSpeed("medium");
    else setSpeed("fast");
  };

  const dynamicColor = color.toLowerCase();

  return (
    <div className="slider-section">
         <p
        className="speed-label"
        style={{ color: dynamicColor, fontWeight: "bold" }}
      >
        {position === 1
          ? "Slow"
          : position === 2
          ? "Medium"
          : "Fast"}
      </p>
      <input
        type="range"
        min="1"
        max="3"
        step="1"
        value={position}
        className="slider"
        onClick={handleClick}
        readOnly
        style={{
          accentColor: dynamicColor,
          "--slider-color": dynamicColor,
        }}
      />
    </div>
  );
}

export default SliderControl;
