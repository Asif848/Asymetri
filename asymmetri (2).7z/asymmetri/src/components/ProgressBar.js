import React, { useEffect, useState } from "react";
import { getSpeedDuration, getColorGradient } from "../MyFunction";

function ProgressBar({ speed, color, reverse, index, totalItems, activeIndex, isDefault }) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let duration = getSpeedDuration(speed);
    let value = progress;
    
    if (isDefault) {
      const interval = setInterval(() => {
        value = (value + 2) % 102;
        setProgress(value);
      }, duration);
      return () => clearInterval(interval);
    }
    
    const currentIndex = reverse ? (totalItems - 1 - activeIndex) : activeIndex;
    
    const shouldFill = index === currentIndex;

    const shouldBeComplete = reverse
      ? index > currentIndex
      : index < currentIndex;

    if (shouldFill) {
      value = 0;
      const interval = setInterval(() => {
        if (value < 100) {
          value += 2;
          setProgress(value);
        } else {
          clearInterval(interval);
        }
      }, duration);
      return () => clearInterval(interval);
    } else if (shouldBeComplete && currentIndex !== 0) {
      setProgress(100);
    } else {
      setProgress(0);
    }
  }, [speed, reverse, index, activeIndex, totalItems]);

  return (
    <div className="progress-bar">
      <div
        className="progress-fill"
        style={{
          width: `${progress}%`,
          background: getColorGradient(color),
          marginLeft: reverse ? 'auto' : '0',
          transform: reverse ? 'scaleX(-1)' : 'none'
        }}
      ></div>
    </div>
  );
}

export default ProgressBar;
