import React from "react";
import { colors } from "../MyData";

function ColorSelector({ setColor }) {
  return (
    <select
      className="dropdown"
      onChange={(e) => setColor(e.target.value)}
      defaultValue="Green"
    >
      {colors.map((color, index) => (
        <option key={index} value={color}>
          {color}
        </option>
      ))}
    </select>
  );
}

export default ColorSelector;
