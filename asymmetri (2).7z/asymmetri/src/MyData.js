export const colors = ["Red", "Purple", "Green", "Blue"];
