import React, { useState, useEffect } from "react";
import "./App.css";
import Header from "./components/Header";
import ColorSelector from "./components/ColorSelector";
import SliderControl from "./components/SliderControl";
import InputBoxes from "./components/InputBoxes";
import ToggleSwitch from "./components/ToggleSwitch";
import ProgressBar from "./components/ProgressBar";

function App() {
  const [speed, setSpeed] = useState("medium");
  const [color, setColor] = useState("Green");
  const [totalItems, setTotalItems] = useState("");
  const [itemsInLine, setItemsInLine] = useState("");
  const [reverse, setReverse] = useState(false);
  const [error, setError] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);

  const handleTotalChange = (val) => {
    if (val > 30) {
      setError("Only 30 items allowed.");
    } else {
      setError("");
      setTotalItems(val);
    }
  };

  const handleItemsInLineChange = (val) => {
    if (val > 15) {
      setError("Only 15 items allowed");
    } else {
      setError("");
      setItemsInLine(val);
    }
  };

  useEffect(() => {
    const duration = speed === "slow" ? 6000 : speed === "fast" ? 2000 : 3000;
    const interval = setInterval(() => {
      setActiveIndex(prev => {
        if (prev >= totalItems - 1) {
          return 0;
        }
        return prev + 1;
      });
    }, duration);

    return () => clearInterval(interval);
  }, [speed, totalItems]);

  return (
    <div className="app-container">
      {error && (
        <div className="error-text">
          <strong>Validation Error</strong>
          <br />
          {error}
        </div>
      )}
      <Header />
      <ColorSelector setColor={setColor} />
      <SliderControl setSpeed={setSpeed} color={color} />
      <InputBoxes
        color={color}
        totalItems={totalItems}
        itemsInLine={itemsInLine}
        handleTotalChange={handleTotalChange}
        handleItemsInLineChange={handleItemsInLineChange}
      />
      <ToggleSwitch reverse={reverse} setReverse={setReverse} color={color} />

      <div
        className="progress-grid"
        style={{
          gridTemplateColumns: `repeat(${itemsInLine || 1}, 1fr)`,
        }}
      >
        {totalItems ? (
          Array.from({ length: totalItems }).map((_, i) => (
            <ProgressBar 
              key={i} 
              speed={speed} 
              color={color} 
              reverse={reverse}
              index={i}
              totalItems={totalItems}
              activeIndex={activeIndex}
            />
          ))
        ) : (
          <ProgressBar 
            key="default"
            speed={speed} 
            color={color} 
            reverse={reverse}
            index={0}
            totalItems={1}
            activeIndex={0}
            isDefault={true}
          />
        )}
      </div>
    </div>
  );
}

export default App;
